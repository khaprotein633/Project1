# About Project

This is a Admin Dashboard Frontend project build on React with Syncfusion fast development component tool.

It has features such as-

1. UserProfile
2. Notifications
3. Chat
4. Shopping Cart
5. Multiple Theme Setting
6. Charts (pie, sparkline, pyramid etc.)
7. Calendar
8. Kanban
9. Color-picker
10. Editor

Project link is in description! Let me know your feedback on these project.
